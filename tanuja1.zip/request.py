import requests

url = 'http://localhost:5000/predict_api'
r = requests.post(url,json={'stepcount':5464, 'hoursofsleep':5, 'weight_kg':66})

print(r.json())
